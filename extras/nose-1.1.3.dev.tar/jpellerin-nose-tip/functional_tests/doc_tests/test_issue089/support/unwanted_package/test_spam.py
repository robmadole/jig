def test_spam():
    assert True

