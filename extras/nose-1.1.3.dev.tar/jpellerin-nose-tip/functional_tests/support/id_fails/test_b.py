def test():
    pass

def test_fail():
    assert False
