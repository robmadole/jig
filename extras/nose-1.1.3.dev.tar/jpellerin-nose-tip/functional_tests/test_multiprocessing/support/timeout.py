
def test_timeout():
    "this test *should* fail when process-timeout=1"
    from time import sleep
    sleep(2)

